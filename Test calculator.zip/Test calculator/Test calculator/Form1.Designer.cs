﻿namespace Test_calculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.n1 = new System.Windows.Forms.Button();
            this.n2 = new System.Windows.Forms.Button();
            this.n3 = new System.Windows.Forms.Button();
            this.n4 = new System.Windows.Forms.Button();
            this.n5 = new System.Windows.Forms.Button();
            this.n6 = new System.Windows.Forms.Button();
            this.n7 = new System.Windows.Forms.Button();
            this.n8 = new System.Windows.Forms.Button();
            this.n9 = new System.Windows.Forms.Button();
            this.n0 = new System.Windows.Forms.Button();
            this.nAdd = new System.Windows.Forms.Button();
            this.nSub = new System.Windows.Forms.Button();
            this.nMul = new System.Windows.Forms.Button();
            this.nDiv = new System.Windows.Forms.Button();
            this.nRes = new System.Windows.Forms.Button();
            this.ndot = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.textBox1.Location = new System.Drawing.Point(35, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(544, 29);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // n1
            // 
            this.n1.Location = new System.Drawing.Point(35, 90);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(75, 62);
            this.n1.TabIndex = 1;
            this.n1.Text = "1";
            this.n1.UseVisualStyleBackColor = true;
            this.n1.Click += new System.EventHandler(this.n1_Click);
            // 
            // n2
            // 
            this.n2.Location = new System.Drawing.Point(151, 90);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(75, 62);
            this.n2.TabIndex = 2;
            this.n2.Text = "2";
            this.n2.UseVisualStyleBackColor = true;
            this.n2.Click += new System.EventHandler(this.n2_Click);
            // 
            // n3
            // 
            this.n3.Location = new System.Drawing.Point(270, 90);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(75, 62);
            this.n3.TabIndex = 3;
            this.n3.Text = "3";
            this.n3.UseVisualStyleBackColor = true;
            this.n3.Click += new System.EventHandler(this.n3_Click);
            // 
            // n4
            // 
            this.n4.Location = new System.Drawing.Point(387, 90);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(75, 62);
            this.n4.TabIndex = 4;
            this.n4.Text = "4";
            this.n4.UseVisualStyleBackColor = true;
            this.n4.Click += new System.EventHandler(this.n4_Click);
            // 
            // n5
            // 
            this.n5.Location = new System.Drawing.Point(504, 90);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(75, 62);
            this.n5.TabIndex = 5;
            this.n5.Text = "5";
            this.n5.UseVisualStyleBackColor = true;
            this.n5.Click += new System.EventHandler(this.n5_Click);
            // 
            // n6
            // 
            this.n6.Location = new System.Drawing.Point(35, 180);
            this.n6.Name = "n6";
            this.n6.Size = new System.Drawing.Size(75, 62);
            this.n6.TabIndex = 6;
            this.n6.Text = "6";
            this.n6.UseVisualStyleBackColor = true;
            this.n6.Click += new System.EventHandler(this.n6_Click);
            // 
            // n7
            // 
            this.n7.Location = new System.Drawing.Point(151, 180);
            this.n7.Name = "n7";
            this.n7.Size = new System.Drawing.Size(75, 62);
            this.n7.TabIndex = 7;
            this.n7.Text = "7";
            this.n7.UseVisualStyleBackColor = true;
            this.n7.Click += new System.EventHandler(this.n7_Click);
            // 
            // n8
            // 
            this.n8.Location = new System.Drawing.Point(270, 180);
            this.n8.Name = "n8";
            this.n8.Size = new System.Drawing.Size(75, 62);
            this.n8.TabIndex = 8;
            this.n8.Text = "8";
            this.n8.UseVisualStyleBackColor = true;
            this.n8.Click += new System.EventHandler(this.n8_Click);
            // 
            // n9
            // 
            this.n9.Location = new System.Drawing.Point(387, 180);
            this.n9.Name = "n9";
            this.n9.Size = new System.Drawing.Size(75, 62);
            this.n9.TabIndex = 9;
            this.n9.Text = "9";
            this.n9.UseVisualStyleBackColor = true;
            this.n9.Click += new System.EventHandler(this.n9_Click);
            // 
            // n0
            // 
            this.n0.Location = new System.Drawing.Point(504, 180);
            this.n0.Name = "n0";
            this.n0.Size = new System.Drawing.Size(75, 62);
            this.n0.TabIndex = 10;
            this.n0.Text = "0";
            this.n0.UseVisualStyleBackColor = true;
            this.n0.Click += new System.EventHandler(this.n0_Click);
            // 
            // nAdd
            // 
            this.nAdd.Location = new System.Drawing.Point(35, 266);
            this.nAdd.Name = "nAdd";
            this.nAdd.Size = new System.Drawing.Size(59, 62);
            this.nAdd.TabIndex = 11;
            this.nAdd.Text = "+";
            this.nAdd.UseVisualStyleBackColor = true;
            this.nAdd.Click += new System.EventHandler(this.nAdd_Click);
            // 
            // nSub
            // 
            this.nSub.Location = new System.Drawing.Point(119, 266);
            this.nSub.Name = "nSub";
            this.nSub.Size = new System.Drawing.Size(63, 62);
            this.nSub.TabIndex = 12;
            this.nSub.Text = "-";
            this.nSub.UseVisualStyleBackColor = true;
            this.nSub.Click += new System.EventHandler(this.nSub_Click);
            // 
            // nMul
            // 
            this.nMul.Location = new System.Drawing.Point(206, 266);
            this.nMul.Name = "nMul";
            this.nMul.Size = new System.Drawing.Size(61, 62);
            this.nMul.TabIndex = 13;
            this.nMul.Text = "X";
            this.nMul.UseVisualStyleBackColor = true;
            this.nMul.Click += new System.EventHandler(this.nMul_Click);
            // 
            // nDiv
            // 
            this.nDiv.Location = new System.Drawing.Point(299, 266);
            this.nDiv.Name = "nDiv";
            this.nDiv.Size = new System.Drawing.Size(62, 62);
            this.nDiv.TabIndex = 14;
            this.nDiv.Text = "/";
            this.nDiv.UseVisualStyleBackColor = true;
            this.nDiv.Click += new System.EventHandler(this.nDiv_Click);
            // 
            // nRes
            // 
            this.nRes.Location = new System.Drawing.Point(479, 266);
            this.nRes.Name = "nRes";
            this.nRes.Size = new System.Drawing.Size(100, 62);
            this.nRes.TabIndex = 15;
            this.nRes.Text = "=";
            this.nRes.UseVisualStyleBackColor = true;
            this.nRes.Click += new System.EventHandler(this.nRes_Click);
            // 
            // ndot
            // 
            this.ndot.Location = new System.Drawing.Point(400, 266);
            this.ndot.Name = "ndot";
            this.ndot.Size = new System.Drawing.Size(62, 62);
            this.ndot.TabIndex = 16;
            this.ndot.Text = ".";
            this.ndot.UseVisualStyleBackColor = true;
            this.ndot.Click += new System.EventHandler(this.ndot_Click);
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 363);
            this.Controls.Add(this.ndot);
            this.Controls.Add(this.nRes);
            this.Controls.Add(this.nDiv);
            this.Controls.Add(this.nMul);
            this.Controls.Add(this.nSub);
            this.Controls.Add(this.nAdd);
            this.Controls.Add(this.n0);
            this.Controls.Add(this.n9);
            this.Controls.Add(this.n8);
            this.Controls.Add(this.n7);
            this.Controls.Add(this.n6);
            this.Controls.Add(this.n5);
            this.Controls.Add(this.n4);
            this.Controls.Add(this.n3);
            this.Controls.Add(this.n2);
            this.Controls.Add(this.n1);
            this.Controls.Add(this.textBox1);
            this.Name = "Calculator";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button n1;
        private System.Windows.Forms.Button n2;
        private System.Windows.Forms.Button n3;
        private System.Windows.Forms.Button n4;
        private System.Windows.Forms.Button n5;
        private System.Windows.Forms.Button n6;
        private System.Windows.Forms.Button n7;
        private System.Windows.Forms.Button n8;
        private System.Windows.Forms.Button n9;
        private System.Windows.Forms.Button n0;
        private System.Windows.Forms.Button nAdd;
        private System.Windows.Forms.Button nSub;
        private System.Windows.Forms.Button nMul;
        private System.Windows.Forms.Button nDiv;
        private System.Windows.Forms.Button nRes;
        private System.Windows.Forms.Button ndot;
    }
}

